# -*- coding: utf-8 -*-
"""
Created on Mon Dec 11 13:30:12 2023

@author: bhawya
"""

import numpy as np
import matplotlib.pyplot as plt

def plot_signal_and_fourier(file_path, sampling_rate):
    # Read earthquake amplitudes from the text file
    amplitudes = np.loadtxt(file_path)

    # Assuming a constant time spacing based on the sampling rate
    time = np.arange(0, len(amplitudes)) / sampling_rate

    # Plot the earthquake signal
    plt.figure(figsize=(12, 6))
    plt.subplot(2, 1, 1)
    plt.plot(time, amplitudes)
    plt.title('Earthquake Signal')
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')

    # Compute and plot the Fourier Transform
    fourier_transform = np.fft.fft(amplitudes)
    frequencies = np.fft.fftfreq(len(time), 0.005)


    plt.subplot(2, 1, 2)
    plt.plot(np.abs(frequencies), np.abs(fourier_transform))
    plt.title('Fourier Transform')
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('Amplitude')
    plt.tight_layout()
    plt.show()
    
# Specify the assumed sampling rate (replace with the actual value if known)
sampling_rate = 1/0.005
    
# Specify the path to your earthquake amplitudes text file
# Call the function to plot the signal and Fourier Transform
file_path1 = "D:\internship\day1\e.txt"
plot_signal_and_fourier(file_path1, sampling_rate)

file_path2 = "D:\internship\day1\y.txt"
plot_signal_and_fourier(file_path2, sampling_rate)


file_path3 = "D:\internship\day1\z.txt"
plot_signal_and_fourier(file_path3, sampling_rate)



