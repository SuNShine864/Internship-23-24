# -*- coding: utf-8 -*-
"""
Created on Wed Dec 13 16:01:42 2023

@author: bhavy
"""

import matplotlib.pyplot as plt
import numpy as np

import csv

# Specify the path to your text file
input_file_path = 'G1.txt'
# Specify the path for the output CSV file
output_csv_path = 'output_data1.csv'

# List to store the flattened numerical values
numerical_values_flat = []

# Read the lines from the file
with open(input_file_path, 'r') as file:
    lines = file.readlines()

# Convert each value in each line to float and store in the flattened list
for line in lines:
    values = line.split()  # Split the line into individual values
    for value in values:
        try:
            numerical_value = float(value)
            numerical_values_flat.append(numerical_value)
        except ValueError:
            print(f"Error: Unable to convert '{value}' to float.")

# Write the flattened values to a CSV file
with open(output_csv_path, 'w', newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    for value in numerical_values_flat:
        csv_writer.writerow([value])


# Specify the path to your CSV file
csv_file_path = 'output_data1.csv'

# List to store the numerical values
numerical_values = []

# Read the numerical values from the CSV file
with open(csv_file_path, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        numerical_values.append(float(row[0]))

# Convert cm/s^2 to m/s^2
numerical_values_m_per_s2 = [value / 100 for value in numerical_values]
numerical_values_normalized = [value / 9.8 for value in numerical_values_m_per_s2]
# Generate time values with spacing of 0.020 sec
time_values = np.arange(0, len(numerical_values_m_per_s2) * 0.020, 0.020)

# Plot the numerical values on the y-axis with time on the x-axis
plt.plot(time_values, numerical_values_normalized, linestyle='-')
plt.title('Acceleration vs Time')
plt.xlabel('Time (seconds)')
plt.ylabel('Acceleration (g)')
plt.show()

fourier_transform = np.fft.fft(numerical_values_normalized)
frequencies = np.fft.fftfreq(len(time_values), 0.002)

inverse_frequencies = 1 / (0.5*np.abs(frequencies))

# Plot the Fourier Transform with respect to the inverse of frequency
plt.plot(inverse_frequencies, np.abs(fourier_transform))

plt.title('Fourier Transform')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Amplitude')
plt.show()




