# -*- coding: utf-8 -*-
"""
Created on Wed Dec 13 16:28:09 2023

@author: bhavy
"""
import re
import csv
import pandas as pd
import matplotlib.pyplot as plt
def get_numbers_as_list(filename):
    try:
        with open(filename, 'r') as file:
            content = file.read()

            # Use regular expression to find numbers with or without space after 'E'
            numbers = re.findall(r'\S+E\s*[\d.-]+', content)

            return numbers

    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        return None

def convert_to_standard_format(number_str):
    # Split the number into mantissa and exponent parts
    mantissa, exponent = number_str.split('E')

    # Convert mantissa to float
    mantissa = float(mantissa)

    # Convert exponent to int and handle negative exponent if needed
    if '-' in exponent:
        power = int(exponent.split('-')[-1])
        mantissa /= 10**power
    else:
        power = int(exponent)
        mantissa *= 10**power

    return mantissa
# Example usage
filename = 'G2.txt'
numbers_list = get_numbers_as_list(filename)

print(numbers_list)

converted_numbers = [convert_to_standard_format(number) for number in numbers_list]

# Create a DataFrame with the converted numbers
df = pd.DataFrame(converted_numbers)

# Save the DataFrame to a CSV file
csv_filename = 'converted_numbers.csv'
df.to_csv(csv_filename, index=False)



# Specify the paths to your CSV files
time_csv_path = 'time.csv'
amplitude_csv_path = 'converted_numbers.csv'

# Initialize empty lists for time and amplitude
time_values = []
amplitude_values = []

# Read time values from time.csv
with open(time_csv_path, 'r') as time_file:
    time_reader = csv.reader(time_file)
    # Assuming the time values are in the first column
    time_values = [float(row[0]) for row in time_reader]

# Read amplitude values from amplitude.csv
with open(amplitude_csv_path, 'r') as amplitude_file:
    amplitude_reader = csv.reader(amplitude_file)
    # Assuming the amplitude values are in the first column
    amplitude_values = [float(row[0]) for row in amplitude_reader]

# Plot the graph
plt.plot(time_values, amplitude_values, label='Amplitude vs. Time')
plt.xlabel('Time')
plt.ylabel('Amplitude')
plt.title('Amplitude vs. Time')
plt.legend()
plt.show()





