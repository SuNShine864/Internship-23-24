# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 17:16:18 2024

@author: bhavy
"""


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error, mean_squared_error, explained_variance_score, r2_score

# Reading csv file
df = pd.read_csv('final_ml_file.csv')

# Extract input features (X) and target variable (y)
X = df.iloc[:, 1:31]  # Columns 1 to 31 as input features
y = df.iloc[:, 31:]  # Columns 32 and onward as the target variable

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Building Support Vector Regression models for each target column
svr_models = []
for column in y_train.columns:
    model = SVR(kernel='linear')  # You can choose different kernels like 'linear', 'rbf', 'poly', etc.
    svr_model = model.fit(X_train, y_train[column])
    svr_models.append(svr_model)

# Prediction on training dataset
y_train_pred = pd.DataFrame({column: model.predict(X_train) for column, model in zip(y_train.columns, svr_models)})

# Evaluation on training dataset
print("On training dataset")
r2_train_scores = [r2_score(y_train[column], y_train_pred[column]) for column in y_train.columns]
average_r2_train = np.mean(r2_train_scores)
print('Average R^2 score on training dataset:', average_r2_train)

# Prediction on testing data
y_test_pred = pd.DataFrame({column: model.predict(X_test) for column, model in zip(y_train.columns, svr_models)})

# Evaluation on testing dataset
print("\nOn testing dataset")
r2_test_scores = [r2_score(y_test[column], y_test_pred[column]) for column in y_test.columns]
average_r2_test = np.mean(r2_test_scores)
print('Average R^2 score on testing dataset:', average_r2_test)



