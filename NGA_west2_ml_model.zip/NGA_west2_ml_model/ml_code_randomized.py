# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 15:45:38 2024

@author: bhavy
"""

from sklearn.model_selection import RandomizedSearchCV
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error,mean_squared_error,explained_variance_score,r2_score
from yellowbrick.regressor import ResidualsPlot
#reading csv file
df=pd.read_csv('final_ml_file.csv')

# Extract input features (X) and target variable (y)
X = df.iloc[:, 1:31]  # Columns 1 to 31 as input features
y = df.iloc[:, 31:]  # Column 32 (or whichever is the target column) as the target variable

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
# Define the hyperparameter grid
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['auto', 'sqrt', 'log2', None]
}

# Create a RandomForestRegressor
rf_model = RandomForestRegressor(random_state=30)

# Instantiate the RandomizedSearchCV object
random_search = RandomizedSearchCV(rf_model, param_distributions=param_grid, n_iter=10, scoring='neg_mean_squared_error', cv=5, random_state=42, n_jobs=-1)

# Fit the RandomizedSearchCV to the data
random_search.fit(X_train, y_train.values.ravel())  # .values.ravel() is used to convert y_train to a 1D array

# Get the best parameters
best_params = random_search.best_params_
print('Best Hyperparameters:', best_params)

# Use the best parameters to create the final model
final_model = RandomForestRegressor(**best_params, random_state=30)
final_model.fit(X_train, y_train.values.ravel())

# Evaluate the final model
y_train_pred_final = final_model.predict(X_train)
y_test_pred_final = final_model.predict(X_test)

# Print evaluation metrics
print("\nOn training dataset with tuned hyperparameters:")
print('The training r_square is :%.2f' % final_model.score(X_train, y_train))
print('The mean absolute error is :%.2f' % mean_absolute_error(y_train, y_train_pred_final))
print('The mean squared error is :%.2f' % mean_squared_error(y_train, y_train_pred_final))
print('The root mean squared error is :%.2f' % np.sqrt(mean_squared_error(y_train, y_train_pred_final)))
print('The EVS is :%.2f' % explained_variance_score(y_train, y_train_pred_final))

print("\nOn testing dataset with tuned hyperparameters:")
print('The testing r_square is :%.2f' % r2_score(y_test, y_test_pred_final))
print('The mean absolute error is :%.2f' % mean_absolute_error(y_test, y_test_pred_final))
print('The mean squared error is :%.2f' % mean_squared_error(y_test, y_test_pred_final))
print('The root mean squared error is :%.2f' % np.sqrt(mean_squared_error(y_test, y_test_pred_final)))
print('The EVS is :%.2f' % explained_variance_score(y_test, y_test_pred_final))

plt.rcParams['figure.figsize']=(10,6)
x_ax=range(len(X_test))
# Plotting observed and predicted data with the final model
plt.plot(x_ax, y_test, label='Observed', color='k', linestyle='-')
plt.plot(x_ax, y_test_pred_final, label='Predicted', color='b', linestyle='--')
plt.show()

# Save residuals with tuned model
residuals_final = y_test_pred_final - y_test
residuals_final.to_csv('residuals_data_tuned.csv', index=False)
