# -*- coding: utf-8 -*-
"""
Created on Fri Dec 22 16:29:25 2023

@author: bhavy
"""

import pandas as pd
import numpy as np
from scipy.interpolate import interp1d
from scipy.fft import fft
import matplotlib.pyplot as plt

# List of files to skip
files_to_skip = [144, 1100, 1101, 1102, 1104, 1108, 1110, 1114, 1115, 1118, 1121]
# Step 1: Read the Files
freq_values = pd.read_csv('freq_values.csv', header=None)[0]
# Read the tdt.csv file
tdt_df = pd.read_csv("tdt.csv")
# Step 2-5: Process Each E*.csv File
fas_columns = []
for i in range(1, 3552):
    if i in files_to_skip:
        continue
    file_name = f'final_nga_files/E{i}.csv'
    df = pd.read_csv(file_name)
    # Step 2: Calculate Fourier Transform
    # Extract amplitude values from column1
    amplitude_values = df["Column2"].values

    # Perform Fourier transform
    n = len(amplitude_values)
    sampling_interval = tdt_df.iloc[i-1, 0] 
    fourier_freq = np.fft.fftfreq(n, d=sampling_interval)
    fourier_amplitude = np.abs(fft(amplitude_values))  # Take absolute value

    # Step 3: Interpolate FAS using linear interpolation with bounds_error=False
    interpolate_fas = interp1d(fourier_freq, fourier_amplitude, kind='linear', fill_value='extrapolate')
    interpolated_fas_values = interpolate_fas(freq_values)

    # Append to the list of columns
    fas_columns.append(interpolated_fas_values.real)

# Create a DataFrame with all FAS columns
final_fas_df = pd.DataFrame(fas_columns).T  # Transpose the DataFrame
final_fas_df.columns = [f'E{i}.FAS' for i in range(1, 3552) if i not in files_to_skip]

# Concatenate all columns at once
final_df = pd.concat([pd.DataFrame({'freq': freq_values}), final_fas_df], axis=1)

# Write to CSV
final_df.to_csv('east-west.csv', index=False)


