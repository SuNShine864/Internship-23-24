# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 14:39:39 2024

@author: bhavy
"""

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error,mean_squared_error,explained_variance_score,r2_score
from yellowbrick.regressor import ResidualsPlot
#reading csv file
df=pd.read_csv('final_ml_file.csv')

# Extract input features (X) and target variable (y)
X = df.iloc[:, 1:31]  # Columns 1 to 31 as input features
y = df.iloc[:, 31:]  # Column 32 (or whichever is the target column) as the target variable

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# building random forest model
model=RandomForestRegressor(n_estimators=100,random_state=30)
LL_rf=model.fit(X_train, y_train)

#training r2 score 
print('The training r_square is :%.2f'% LL_rf.score(X_train, y_train))

#prediction on training dataset
y_train_pred=LL_rf.predict(X_train)

print("On training dataset")
#mean absolute error
print('The mean absolute error is :%.2f'% mean_absolute_error(y_train,y_train_pred))
#mean squared error
print('The mean squared error is :%.2f'% mean_squared_error(y_train,y_train_pred))
#root mean squared error
print('The root mean squared error is :%.2f'% np.sqrt(mean_squared_error(y_train,y_train_pred)))
#explained variance score
print('The EVS is :%.2f'% explained_variance_score(y_train,y_train_pred))

#prediction on testing data
y_test_pred=LL_rf.predict(X_test)

print("On testing dataset")
#testing coefficient of determination
print('The testing r_square is :%.2f'% r2_score(y_test,y_test_pred))
#mean absolute error
print('The mean absolute error is :%.2f'% mean_absolute_error(y_test,y_test_pred))
#mean squared error
print('The mean squared error is :%.2f'% mean_squared_error(y_test,y_test_pred))
#root mean squared error
print('The root mean squared error is :%.2f'% np.sqrt(mean_squared_error(y_test,y_test_pred)))
#explained variance score
print('The EVS is :%.2f'% explained_variance_score(y_test,y_test_pred))

# plotting observed and predicted data
#setting boundaries and parameters
plt.rcParams['figure.figsize']=(10,6)
x_ax=range(len(X_test))
# Plotting
plt.plot(x_ax,y_test,label='Observed',color='k',linestyle='-')
plt.plot(x_ax,y_test_pred,label='Predicted',color='b',linestyle='--')
plt.show()

residuals=y_test_pred-y_test
residuals.to_csv('residuals_data.csv', index=False)
