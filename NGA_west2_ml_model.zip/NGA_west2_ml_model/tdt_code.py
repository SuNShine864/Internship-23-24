# -*- coding: utf-8 -*-
"""
Created on Thu Dec 21 16:14:46 2023

@author: bhavy
"""

import scipy.io
import pandas as pd
import numpy as np

# Load the .mat file
mat_data = scipy.io.loadmat('peernga_data.mat')

# Assuming 'tdt' is the variable in your .mat file
tdt = mat_data['tdt']

# Convert to DataFrame
df = pd.DataFrame(tdt, columns=['Column1', 'Column2', 'Column3'])

# Convert single-element arrays to scalars
df = df.applymap(lambda x: x[0] if isinstance(x, (list, np.ndarray)) and len(x) == 1 else x)

# Save as CSV
#df.to_csv('output_file2.csv', index=False)

def process_value(value):
    try:
        # If the value is a NumPy array, extract the first element
        if isinstance(value, np.ndarray) and value.size == 1:
            return float(value[0])
        # If the value is a string enclosed in brackets, remove brackets and convert to float
        elif isinstance(value, str) and value.startswith('[') and value.endswith(']'):
            return float(value[1:-1])
        else:
            # If the conversion fails, return NaN
            return float('nan')
    except ValueError:
        # If the conversion fails, return NaN
        return float('nan')

# Apply the function to each cell in the DataFrame
df = df.applymap(process_value)


# Iterate over rows
for index, row in df.iterrows():
    # Check if the value in the first column is missing
    if pd.isna(row['Column1']):
        # If the second column is not empty, replace with its value
        if not pd.isna(row['Column2']):
            df.at[index, 'Column1'] = row['Column2']
        # If the second column is empty, check the third column
        elif not pd.isna(row['Column3']):
            df.at[index, 'Column1'] = row['Column3']
        
            

# Save the modified DataFrame to a new CSV file
df.to_csv('your_output_file2312.csv', index=False)

empty_indices = []

# Iterate over rows
for index, row in df.iterrows():
    # Check if all columns in the row are empty
    if all(pd.isna(value) for value in row):
        # Store the index of the row before the empty row
        empty_indices.append(index)

# Create a DataFrame with the stored indices
empty_df = pd.DataFrame({'Empty Indices': empty_indices})

# Save the DataFrame to a CSV file
empty_df.to_csv('empty_files.csv', index=False)

