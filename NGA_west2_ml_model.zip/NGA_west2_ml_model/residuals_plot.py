# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 15:30:29 2024

@author: bhavy
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Reading the DataFrame or CSV file
df = pd.read_csv('residuals_data.csv', header=None)

# Set the first row as the column names
df.columns = df.iloc[0, :]

# Extract first row values and corresponding column values
x_values = df.iloc[0, :]
y_values = df.iloc[1:, :]

# Take the logarithm of x_values
log_x_values = np.log(x_values)

# Plotting the graph
plt.figure(figsize=(10, 6))
for col in df.columns:
    plt.scatter([log_x_values[col]] * len(y_values), y_values[col], label=f'{col}', color='b')

# Plotting the standard deviation line in red
std_dev = np.std(y_values, axis=0)
plt.axhline(std_dev.mean(), color='red', linestyle='--', label='Standard Deviation')

# Plotting the mean deviation line in yellow
mean = np.mean(y_values,axis=1)
plt.axhline(y=np.mean(mean), color='cyan', linestyle='--', label='Mean Deviation')

plt.xlabel('Logarithm of X-axis values (First row)')
plt.ylabel('Y-axis values (From second row onwards)')
plt.title('Scatter Plot of Log(X) and Y values with Std Dev and Mean Dev Lines')

plt.show()