# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 19:17:11 2024

@author: 91945
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, explained_variance_score, r2_score

# Reading csv file(has log 10 values of EAS csv)
df = pd.read_csv('final_ml_file.csv')

# Extract input features (X) and target variable (y)
X = df.iloc[:, 1:31]  # Columns 1 to 31 as input features
y = df.iloc[:, 31:]   # Column 32 (or whichever is the target column) as the target variable

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Building XGBoost model
model = XGBRegressor(n_estimators=30, random_state=30)
model.fit(X_train, y_train)

# Prediction on testing data
y_test_pred = model.predict(X_test)

# Creating a DataFrame for predicted values
df_predictions = pd.DataFrame(y_test_pred, columns=y_test.columns)

# Save the predicted values to a new CSV file
df_predictions.to_csv('predicted_values.csv', index=False)
