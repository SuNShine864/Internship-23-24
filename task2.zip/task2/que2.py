# -*- coding: utf-8 -*-
"""
Created on Tue Dec 12 10:18:34 2023

@author: bhavy
"""

import os
import numpy as np
import matplotlib.pyplot as plt
# Your existing code for processing a single .txt file
def process_txt_file(file_path,sampling_rate):
    # Add your existing code here
    amplitudes = np.loadtxt(file_path)

    # Assuming a constant time spacing based on the sampling rate
    time = np.arange(0, len(amplitudes)) / sampling_rate

    # Plot the earthquake signal
    plt.figure(figsize=(12, 6))
    plt.subplot(2, 1, 1)
    plt.plot(time, amplitudes)
    plt.title('Earthquake Signal')
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude (Cm s-2)')

    # Compute and plot the Fourier Transform
    fourier_transform = np.fft.fft(amplitudes)
    frequencies = np.fft.fftfreq(len(time), 0.005)
    plt.subplot(2, 1, 2)
    plt.plot(np.abs(frequencies), np.abs(fourier_transform))
    plt.title('Fourier Transform')
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('Amplitude')
    plt.tight_layout()
    plt.show()

# Get the current directory
current_directory = os.getcwd()
sampling_rate=200
# Loop over all files in the directory
for filename in os.listdir(current_directory):
    if filename.endswith(".txt"):
        file_path = os.path.join(current_directory, filename)
        process_txt_file(file_path,sampling_rate)