# -*- coding: utf-8 -*-
"""
Created on Tue Dec 12 12:12:21 2023

@author: bhavy
"""

import pandas as pd
import matplotlib.pyplot as plt
import csv
# Read the CSV file
df = pd.read_csv("D:\internship\day2\FAS_ESm.csv")
# Extract data starting from columns 'U', 'V', and 'W'
u_data = df.filter(regex='^U_', axis=1)
v_data = df.filter(regex='^V_', axis=1)
w_data = df.filter(regex='^W_', axis=1)

# Create three separate DataFrames with original first column and extracted data
u_result = pd.concat([df.iloc[:, 0], u_data], axis=1)
v_result = pd.concat([df.iloc[:, 0], v_data], axis=1)
w_result = pd.concat([df.iloc[:, 0], w_data], axis=1)

# Save each result DataFrame to a new CSV file
u_result.to_csv('du_result.csv', index=False)
v_result.to_csv('v_result.csv', index=False)
w_result.to_csv('w_result.csv', index=False)

def plot_frequency_vs_amplitude(file_path,direction):
    # Read header row and extract values
    with open(file_path, 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        header = next(csv_reader)  # Read the header row
        values_to_extract = header[1:]

    # Create a DataFrame and extract values
    df = pd.DataFrame(values_to_extract, columns=['ColumnValues'])
    df['ExtractedValues'] = df['ColumnValues'].str.extract(r'F(\d+)_(\d+)').astype(str).apply(lambda x: '.'.join(x), axis=1)
    df['ExtractedValues'] = df['ExtractedValues'].astype(float)
    
    # Extract frequencies from the DataFrame
    frequency = df['ExtractedValues'].tolist()

    # Read amplitude values from the CSV file
    with open(file_path, 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        
        # Skip the header row
        header = next(csv_reader)

        # Initialize an empty list to store values from the second row
        amplitudes = []

        # Loop through the rows starting from the second row
        for row in csv_reader:
            amplitudes = [float(value) for value in row[1:]]

    # Plot the frequency vs amplitude
    plt.plot(frequency, amplitudes)
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('Amplitude (Cm s-2 Hz-1)')
    plt.title(direction)
    plt.show()

# Specify the file path 
file_path1 = "du_result.csv"
file_path2 = "v_result.csv"
file_path3 = "w_result.csv"
direction_u="u-direction"
direction_v="v-direction"
direction_w="w-direction"
# Call the function to plot frequency vs amplitude
plot_frequency_vs_amplitude(file_path1,direction_u)
plot_frequency_vs_amplitude(file_path2,direction_v)
plot_frequency_vs_amplitude(file_path3,direction_w)
